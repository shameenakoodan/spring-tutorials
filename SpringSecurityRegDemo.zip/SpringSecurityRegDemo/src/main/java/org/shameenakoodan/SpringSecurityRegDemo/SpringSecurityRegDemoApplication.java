package org.shameenakoodan.SpringSecurityRegDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityRegDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityRegDemoApplication.class, args);
	}

}
